package ContactService;


public class Contact {
	private String contactId = null;
	private String contactFirstName = null;
	private String contactLastName = null;
	private String contactPhoneNumber = null;
	private String contactAddress = null;
	
	public Contact(String id, String firstName, String lastName, String phoneNum, String address) {
		if (id == null || id.length() > 10) {
			throw new IllegalArgumentException("Invalid ID");
		}
		if (firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid first name");
		}
		if (lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Invalid last name");
		}
		if (phoneNum == null || phoneNum.length() != 10) {
			throw new IllegalArgumentException("Invalid phone number");
		}
		if (address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid address");
		}
		
		this.contactId = id;
		this.contactFirstName = firstName;
		this.contactLastName = lastName;
		this.contactPhoneNumber = phoneNum;
		this.contactAddress = address;
	}
	
	public void setFirstName(String firstName) {
		if (firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid first name");
		}
		this.contactFirstName = firstName;
	}
	
	public void setLastName(String lastName) {
		if (lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Invalid last name");
		}
		this.contactLastName = lastName;
	}
	
	public void setPhoneNumber(String phoneNum) {
		if (phoneNum == null || phoneNum.length() != 10) {
			throw new IllegalArgumentException("Invalid phone number");
		}
		this.contactPhoneNumber = phoneNum;
	}
	
	public void setAddress(String address) {
		if (address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid address");
		}
		this.contactAddress = address;
	}
	
	public String getContactId() {
		return this.contactId;
	}
	
	public String getContactFirstName() {
		return this.contactFirstName;
	}
	
	public String getContactLastName() {
		return this.contactLastName;
	}
	
	public String getContactPhoneNumber() {
		return this.contactPhoneNumber;
	}

	public String getContactAddress() {
		return this.contactAddress;
	}
	
}
