package ContactService;
import java.util.ArrayList;

public class ContactService {
	private static ArrayList<Contact> contacts = new ArrayList<Contact>();
	
	public ContactService() {
	}
	
	public void addContact() {
		Contact contact = new Contact("12345", "Jimmy", "Bob", "9516238470", "423 bark st.");
		contacts.add(contact);
	}
	
	public void deleteContact() {
		String contactId = "12345";
		
		contacts.forEach((contact) -> {
			if (contact.getContactId() == contactId) {
				contacts.remove(contacts.indexOf(contact));
			}
		});
	}
	
	public void updateContact(String id) {
		contacts.forEach((Contact person)-> {
			if (person.getContactId() == id) {
				person.setFirstName("Timmy");
				person.setLastName("Turner");
				person.setPhoneNumber("1234569878");
				person.setAddress("423 silver trot");
			};
		});
	}
	
	public static ArrayList<Contact> getContacts() {
		return contacts;
	}
}
