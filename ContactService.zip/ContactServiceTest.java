package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import ContactService.ContactService;

class ContactServiceTest {
	ContactService contactService = new ContactService();
	@Test
	void testContactServiceAdd() {
		contactService.addContact();
		assertTrue(contactService.getContacts().size() == 1);
	}
	@Test 
	void testCotnactServiceUpdate() {
		assertTrue(contactService.getContacts().get(0).getContactFirstName() == "Jimmy");
		contactService.updateContact("12345");
		assertTrue(contactService.getContacts().get(0).getContactFirstName() == "Timmy");
	}
	@Test
	void testContactServiceDelete() {
		contactService.deleteContact();
		assertTrue(ContactService.getContacts().size() == 0);
	}
}
