package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import ContactService.Contact;

class ContactTest {

	@Test
	void testContact() {
		Contact contact = new Contact("12345", "Jimmy", "Bob", "1592634870", "524 pickle way");
		assertTrue(contact.getContactId().equals("12345"));
		assertTrue(contact.getContactFirstName().equals("Jimmy"));
		assertTrue(contact.getContactLastName().equals("Bob"));
		assertTrue(contact.getContactPhoneNumber().equals("1592634870"));
		assertTrue(contact.getContactAddress().equals("524 pickle way"));
	}
	
	@Test
	void testContactIdNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "Jimmy", "Bob", "1592634870", "524 pickle way");
		});
	}
	
	@Test
	void testContactIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678901", "Jimmy", "Bob", "1592634870", "524 pickle way");
		});
	}
	
	@Test
	void testContactFirstNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", null, "Bob", "1592634870", "524 pickle way");
		});
	}
	
	@Test
	void testContactFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "Jimmyjimmyo", "Bob", "1592634870", "524 pickle way");
		});
	}
	
	@Test
	void testContactLastNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "Jimmy", null, "1592634870", "524 pickle way");
		});
	}
	
	@Test
	void testContactLastNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "Jimmy", "Bobbobbobbob", "1592634870", "524 pickle way");
		});
	}
	
	@Test
	void testContactPhoneNumberNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "Jimmy", "Bob", null, "524 pickle way");
		});
	}
	
	@Test
	void testContactPhoneNumberNotTenChar() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "Jimmy", "Bob", "123456789", "524 pickle way");
		});
	}
	
	@Test
	void testContactAddressNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "Jimmy", "Bob", "1592634870", null);
		});
	}
	
	@Test
	void testContactAddressTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "Jimmy", "Bob", "1592634870", "1234567890123456789012345678901");
		});
	}
}
